## 源码备注

- hx-key：按键识别
- hx-lcd1602-lcd2004：I2C-液晶显示器1602和2004
- hx-led：驱动LED灯
- hx-nvs：NVS数据保存
- hx-oled：I2C-OLED显示
- hx-pwm：PWM全彩LED灯显示
- hx-sht30：I2C-读取温湿度
- hx-tim：定时器实验
- hx-tm1638：tm1638芯片IO扩展（数码管，LED灯、按键识别）
- hx-uart：两个UART实验

### 总结

- ESP32技术交流QQ群：824870185

- 作者：开源一小步

- CSDN：https://blog.csdn.net/qq_24550925/ 