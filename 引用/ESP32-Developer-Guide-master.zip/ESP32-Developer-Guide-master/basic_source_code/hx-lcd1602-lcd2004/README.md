ESP32 驱动lcd1602，IIC接口
## 感谢开源提供者：伽岚

### 使用步骤
- 下载源码，将componets文件夹中的库全部复制到SDK的componets文件夹中
- make clean -> make menuconfig -> make all ->make flash
### 总结

ESP32技术交流QQ群：824870185

作者：红旭无线团队
CSDN：https://blog.csdn.net/qq_24550925/ 