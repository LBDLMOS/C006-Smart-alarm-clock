## 源码备注

- hx-https-mbedtls：HTTPS获取天气
- hx-mqtt-domain-name：外网MQTT测试自点灯（域名）
- hx-mqtt-tcp：本地MQTT交互
- hx-mqtt-wan：外网MQTT测试自点灯（IP）
- hx-ota：ESP32的空中升级（OTA）
- hx-sc-http：HTTP获取城市温度
- hx-sc：SmartConfig一键配置
- hx-tcp： ESP32的TCP连接
- hx-tmall：天猫精灵控制ESP32
- hx-udp：ESP32的UDP广播
- hx-wifi： 新建一个WIFI热点
- hx-ws：ESP32的WebSocket服务器

### 总结

- ESP32技术交流QQ群：824870185

- 作者：开源一小步

- CSDN：https://blog.csdn.net/qq_24550925/ 