# ESP32-Developer-Guide

### 基础部分（完成）

- #### [教程](https://github.com/HX-IoT/ESP32-Developer-Guide/tree/master/%E6%95%99%E7%A8%8B%EF%BC%9AESP32%E5%BC%80%E5%8F%91%E6%8C%87%E5%8D%97%EF%BC%88%E5%BC%80%E6%BA%90%E4%B8%80%E5%B0%8F%E6%AD%A5%EF%BC%89) 

- #### [源码](https://github.com/HX-IoT/ESP32-Developer-Guide/tree/master/basic_source_code)

### WiFi部分（完成）

- #### [教程](https://github.com/HX-IoT/ESP32-Developer-Guide/tree/master/%E6%95%99%E7%A8%8B%EF%BC%9AESP32%E5%BC%80%E5%8F%91%E6%8C%87%E5%8D%97%EF%BC%88%E5%BC%80%E6%BA%90%E4%B8%80%E5%B0%8F%E6%AD%A5%EF%BC%89) 

- #### [源码](https://github.com/HX-IoT/ESP32-Developer-Guide/tree/master/wifi_source_code)

### 蓝牙部分

暂无计划。

### 总结

- ESP32技术交流QQ群：824870185

- 作者：开源一小步

- CSDN：https://blog.csdn.net/qq_24550925/ 
